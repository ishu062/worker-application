export class Tutorial {
  id?: any;
  title?: string;
  job?: string;
  mobile?: string;
  email?: string;
  place?: string;
}
